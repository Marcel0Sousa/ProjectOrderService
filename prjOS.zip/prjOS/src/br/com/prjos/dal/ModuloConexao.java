package br.com.prjos.dal;

//importação do conjunto de bibliotecas para trabalhar com SQL
import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author tchelo
 */
public class ModuloConexao {

    // metodo para realizar conexão com DB
    // Connection é um framework incluso no pacote java.sql.* e o "conector" é o metodo
    public static Connection conector() {
        // A variavel "conexao" recebe a String de conexão atribuida na linha 17
        java.sql.Connection conexao = null;
        // Realizando a chamada do driver de conexao
        String driver = "com.mysql.jdbc.Driver";
        // vareavel "url" seta o caminho do DB local
        String url = "jdbc:mysql://localhost:3306/prjos";
        String user = "root";
        String password = "";
        /**
         * Estabelecendo a conexao com o DB e realizando tratamento de erros
         */
        try {
            Class.forName(driver);
            conexao = DriverManager.getConnection(url, user, password);
            return conexao;
        } catch (Exception e) {
            // Exibindo o erro
            // JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }

}
